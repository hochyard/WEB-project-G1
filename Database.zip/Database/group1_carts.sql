create table carts
(
    Customer_email varchar(50) not null,
    ProductID      int         not null,
    primary key (Customer_email, ProductID),
    constraint Carts_customers_Email_fk
        foreign key (Customer_email) references customers (Email),
    constraint Carts_products_ProductID_fk
        foreign key (ProductID) references products (ProductID)
);

INSERT INTO group1.carts (Customer_email, ProductID) VALUES ('yardenh@gmail.com', 1);
INSERT INTO group1.carts (Customer_email, ProductID) VALUES ('adidanovich@gmail.com', 19);
INSERT INTO group1.carts (Customer_email, ProductID) VALUES ('hgreener@gmail.com', 27);