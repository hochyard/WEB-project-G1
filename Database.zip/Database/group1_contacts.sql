create table contacts
(
    ID         int auto_increment
        primary key,
    First_name varchar(20) null,
    Phone      varchar(20) null,
    Last_name  varchar(20) null,
    Email      varchar(50) not null,
    Comment    text        null,
    Seller     varchar(50) null,
    constraint Contacts_sellers_Email_fk
        foreign key (Seller) references sellers (Email)
);

