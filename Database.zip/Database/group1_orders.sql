create table orders
(
    OrderID          int auto_increment
        primary key,
    `Adress-city`    varchar(20) not null,
    `Adress-street`  varchar(20) not null,
    `Address-number` int         null,
    Customer_email   varchar(50) not null,
    Card_number      varchar(30) not null,
    Shipment_price   int         not null,
    constraint `Orders_credit cardes_Card number_fk`
        foreign key (Card_number) references `credit cardes` (`Card number`),
    constraint Orders_customers_Email_fk
        foreign key (Customer_email) references customers (Email)
);

