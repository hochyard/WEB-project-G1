create table events
(
    Seller           varchar(50) not null,
    Datetime         datetime    not null,
    `Address-city`   varchar(20) not null,
    `Address-street` varchar(20) not null,
    `Address-number` int         not null,
    primary key (Seller, Datetime),
    constraint Events___seller
        foreign key (Seller) references sellers (Email)
);

INSERT INTO group1.events (Seller, Datetime, `Address-city`, `Address-street`, `Address-number`) VALUES ('adidanovich@gmail.com', '2021-01-19 17:00:00', 'תל אביב', 'שלמה בן יוסף', 13);
INSERT INTO group1.events (Seller, Datetime, `Address-city`, `Address-street`, `Address-number`) VALUES ('darpelta@gmail.com', '2021-02-24 12:00:00', 'חולון', 'בבלי', 24);
INSERT INTO group1.events (Seller, Datetime, `Address-city`, `Address-street`, `Address-number`) VALUES ('debbyk@gmail.com', '2021-05-01 09:00:00', 'בת ים', 'היובל', 21);