create table products
(
    ProductID          int auto_increment
        primary key,
    Name               varchar(20) not null,
    Price              double      not null,
    PriceAfterDiscount double      null,
    Brand              varchar(10) null,
    Material           varchar(20) null,
    Seller             varchar(50) null,
    Size               varchar(10) null,
    constraint Products_sellers_Email_fk
        foreign key (Seller) references sellers (Email)
);

INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('תיק גב נייק', 100, 90, 'NIKE', 'בד', 'yardenh@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מגף שחור', 90, 70, 'Steve Madd', 'עור', 'ronirabinovich@gmail.com', '40');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מגפון', 100, 60, 'ADDICT', null, 'michallevy@gmail.com', '39');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שמלה בגוון אפור', 60, 40, 'HONIGMAN', 'כותנה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('עגילי חישוק', 10, null, 'ASOS', 'גולדפילד', 'yardenh@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('נעלי בית', 60, 40, 'ALI', 'פרווה', 'adidanovich@gmail.com', '39');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('גומייה לשיער', 10, null, 'Super Phar', null, 'adidanovich@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('כובע צמר', 20, null, 'Xray', 'צמר 70%', 'yardenh@gmail.com', 'M');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('נעלי עקב ברונזה', 60, null, 'ALDO', null, 'michallevy@gmail.com', '38');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('ג''ינס ארוך בהיר', 120, 110, 'Top Shop', 'ג''ינס', 'ronirabinovich@gmail.com', '36');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מכנס טרנינג ', 50, null, 'ASOS', 'כותנה 60%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שרשרת', 20, null, 'TOMER & AS', 'ציפוי כסף', 'yardenh@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('אוברול שחור', 100, 90, 'ZARA', 'כותנה 70%', 'michallevy@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מכנס מחויט', 80, null, 'HaCarmel', 'כותנה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('ארנק שחור', 70, null, 'Gucci', 'עור 80%', 'yardenh@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('צעיף', 55, 40, 'Prvate Col', 'קשמיר 50%', 'yardenh@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חולצת טי-שירט ירח', 40, null, 'FOX', 'כותנה 70%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שורט שחור', 40, null, 'Top Shop', 'כותנה 80%', 'adidanovich@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חצאית קורדרוי', 60, 30, 'Mando', 'קורדרוי', 'adidanovich@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חצאית וינטג''', 50, null, 'GRIP', 'כותנה 50%', 'yardenh@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טרנינג נייק', 130, null, 'Nike', 'כותנה 80%', 'adidanovich@gmail.com', 'M');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שורט נקודות', 40, null, 'ASOS', 'כותנה 50%', 'yardenh@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טופ ספורט נייק', 70, null, 'NIKE', 'לייקרה 70%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טישרט בייסיק לבנה', 30, null, 'FOX', 'לייקרה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('תיק גב נייק', 100, 90, 'NIKE', 'בד', 'hgreener@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מגף שחור', 90, 70, 'Steve Madd', 'עור', 'hgreener@gmail.com', '40');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מגפון', 100, 60, 'ADDICT', null, 'hgreener@gmail.com', '39');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שמלה בגוון אפור', 60, 40, 'HONIGMAN', 'כותנה 70%', 'hgreener@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('עגילי חישוק', 10, null, 'ASOS', 'גולדפילד', 'hgreener@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('נעלי בית', 60, 40, 'ALI', 'פרווה', 'mayadvash@gmail.com', '39');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('גומייה לשיער', 10, null, 'Super Phar', null, 'mayadvash@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('כובע צמר', 20, null, 'Xray', 'צמר 70%', 'mayadvash@gmail.com', 'M');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('נעלי עקב ברונזה', 60, null, 'ALDO', null, 'mayadvash@gmail.com', '38');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('ג''ינס ארוך בהיר', 120, 110, 'Top Shop', 'ג''ינס', 'mayadvash@gmail.com', '36');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מכנס טרנינג ', 50, null, 'ASOS', 'כותנה 60%', 'mayadvash@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שרשרת', 20, null, 'TOMER & AS', 'ציפוי כסף', 'liansimon@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('אוברול שחור', 100, 90, 'ZARA', 'כותנה 70%', 'liansimon@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('מכנס מחויט', 80, null, 'HaCarmel', 'כותנה 70%', 'liansimon@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('ארנק שחור', 70, null, 'Gucci', 'עור 80%', 'debbyk@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('צעיף', 55, 40, 'Prvate Col', 'קשמיר 50%', 'debbyk@gmail.com', null);
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חולצת טי-שירט ירח', 40, null, 'FOX', 'כותנה 70%', 'sapp@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שורט שחור', 40, null, 'Top Shop', 'כותנה 80%', 'omerbabi@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חצאית קורדרוי', 60, 30, 'Mando', 'קורדרוי', 'omerbabi@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('חצאית וינטג''', 50, null, 'GRIP', 'כותנה 50%', 'omerbabi@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טרנינג נייק', 130, null, 'Nike', 'כותנה 80%', 'omerbabi@gmail.com', 'M');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('שורט נקודות', 40, null, 'ASOS', 'כותנה 50%', 'darpelta@gmail.com', 'S');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טופ ספורט נייק', 70, null, 'NIKE', 'לייקרה 70%', 'oriklier@gmail.com', 'L');
INSERT INTO group1.products (Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES ('טישרט בייסיק לבנה', 30, null, 'FOX', 'לייקרה 70%', 'oriklier@gmail.com', 'S');