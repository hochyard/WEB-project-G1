create table sellers
(
    Email            varchar(50)  not null
        primary key,
    `Adrdress-city`  varchar(20)  null,
    `Address-street` varchar(20)  null,
    `Address-number` int          null,
    Description      text         not null,
    Photo_URL        varchar(255) not null,
    constraint Sellers___customer
        foreign key (Email) references customers (Email)
);

INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('adidanovich@gmail.com', 'רעננה', 'בילו', 50, 'היי בנות, קוראים לי עדי ואני אוהבת בגדים ואופנה מגיל צעיר. מקווה שתהנו מהארון שלי!', 'adi.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('darpelta@gmail.com', 'יהוד', 'מנדלסןם', 23, 'חנות יד שניה של מלא פריטים מטורפים ומלאי סטייל מהארון שלי במצב מצויין. מקווה שתהנו מהפריטים כמו שאני נהניתי 3>', 'dar.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('debbyk@gmail.com', 'חולון', 'רוטשילד', 117, 'היי אהובות שלי! ברוכות הבאות לארון שלי! אני מוכרת בגדים שאני כבר לא לובשת, במצב מעולה וחלקם אפילו לא נלבשו מעולם! לכל שאלה, אני שמינה בצור קשר :)', 'debby.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('hgreener@gmail.com', 'חולון', 'זבוטינסקי', 23, 'בנות יקרות שלי, איזה כיף שהגעתן לעמוד שלי!! מקווה שתאהבו, לכל דבר שצטרכו אני כאן 3>', 'hadar.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('liansimon@gmail.com', 'נתניה', 'קוסובסקי', 41, 'היי אהובות! איזה כיף להיות באתר הזה ולקחת חלק ברעיון המטורף הזה! מודה שקצת באיחור, אבל הגיע זמני להצטרף! אשמח לשמוע מכן על כל דבר שתרצו 3>', 'lian.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('mayadvash@gmail.com', 'באר-שבע', 'דרך-מצדה', 114, 'היי אהובות, אני מאיה בת 27 צלמת אופנה ומדיה וכמובןן חיה ונושמת אופנה! אוהבת ושמחה להכיר, נשיקות', 'maya.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('michallevy@gmail.com', 'תל-אביב', 'סוקולוב', 17, 'שלום לכולן, אני מיכל אבל כל החברות קוראות לי מיכ. אני פאשניסטה בלב ובלוגרית אופנה מאז שאני זוכרת את עצמי ', 'michal.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('omerbabi@gmail.com', 'חדרה', 'שימעוני', 16, 'היי בננות, כל הבגדים כאן במצב חדש לחלוטין ונלבשו פעם אחת בלבד. אשמח שתפנו אלי בכל שאלה שיש לכן :)', 'omer.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('oriklier@gmail.com', 'תל-אביב', 'אבן-גבירול', 15, 'היי :) כאן תמצאו פריטי יד 2 מהארון הפרטי שלי ', 'ori.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('ronirabinovich@gmail.com', 'רעננה', 'ארלוזרוב', 34, 'היי בנות, אני רוני בת 26 מתל אביב ומאפרת במקצועי. מזמינה אותכן לקבל הצצה לארון שלי. תהנו :)', 'roni.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('sapp@gmail.com', 'שדרות', 'שדרות רגר', 32, 'היי בנות! איזה כיף שזכיתי להצטרף לאתר הזה ולהציג את עצמי בפניכן.. אני סטונדטית לתואר שני בכלכלה ובעיקר אוהבת לקנות בגדים בלי הרבה תכלית ואז לשלוח אותם בחזרה, והחלטתי לחסוך את המשלוח ולהראות לכם- אולי תאהבו 3>', 'sappir.jpeg');
INSERT INTO group1.sellers (Email, `Adrdress-city`, `Address-street`, `Address-number`, Description, Photo_URL) VALUES ('yardenh@gmail.com', 'תל-אביב', 'הזוהר', 45, 'שלום לכל השוות שבחרו לבקר בדף שלי! למי שלא מכירה, אני ירדן, מתעמלת אומנותית בת 26 מתל אביב. בזמני הפנוי אני אוהבת לגלוש באתרים ולעשות קניות ולהתכרבל עם ליצי הכלבה שלי :))', 'yarden.jpeg');