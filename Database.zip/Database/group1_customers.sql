create table customers
(
    Email      varchar(50)      not null
        primary key,
    First_name varchar(30)      not null,
    Last_name  varchar(30)      not null,
    City       varchar(20)      null,
    Password   varchar(20)      not null,
    Commercial char default '0' null,
    constraint Customers___city
        foreign key (City) references cities (City_Name)
);

INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('adidanovich@gmail.com', 'עדי', 'דנוביץ', 'רעננה', 'ckmcscklmas33', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('darpelta@gmail.com', 'דר', 'פלטה', 'יהוד', '64ארכ', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('debbyk@gmail.com', 'דבי', 'קלמי', 'חולון', 'א43א4ערכר', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('galShapira@gmail.com', 'גל', 'שפירא', 'באר שבע', 'galTheQueen2', '0');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('hgreener@gmail.com', 'הדר', 'גרינר', 'חולון', 'כגנגכ4', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('liansimon@gmail.com', 'ליאן', 'סימון', 'נתניה', '234235', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('mayadvash@gmail.com', 'מאיה', 'דבש', 'באר שבע', 'עגעגכ4', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('michallevy@gmail.com', 'מיכל', 'לוי', 'תל אביב', '523532', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('omerbabi@gmail.com', 'עומר', 'באבי', 'חדרה', '54אגב', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('oriklier@gmail.com', 'אורי', 'קלייר', 'תל אביב', '54אר', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('ronirabinovich@gmail.com', 'רוני ', 'רבינוביץ', 'רעננה', 'קעגנב', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('sapp@gmail.com', 'ספיר', 'גאלי', 'שדרות', '432קרעכגב', '1');
INSERT INTO group1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('yardenh@gmail.com', 'ירדן', 'הוכנברג', 'תל אביב', 'ערערקר5', '1');