create table cities
(
    City_Name varchar(20) not null
        primary key
);

INSERT INTO group1.cities (City_Name) VALUES ('באר שבע');
INSERT INTO group1.cities (City_Name) VALUES ('חדרה');
INSERT INTO group1.cities (City_Name) VALUES ('חולון');
INSERT INTO group1.cities (City_Name) VALUES ('חיפה');
INSERT INTO group1.cities (City_Name) VALUES ('יבנה');
INSERT INTO group1.cities (City_Name) VALUES ('יהוד');
INSERT INTO group1.cities (City_Name) VALUES ('כפר תבור');
INSERT INTO group1.cities (City_Name) VALUES ('נתניה');
INSERT INTO group1.cities (City_Name) VALUES ('קיסריה');
INSERT INTO group1.cities (City_Name) VALUES ('רעננה');
INSERT INTO group1.cities (City_Name) VALUES ('שדרות');
INSERT INTO group1.cities (City_Name) VALUES ('תל אביב');