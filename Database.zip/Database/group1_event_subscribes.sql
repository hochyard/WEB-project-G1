create table `event subscribes`
(
    seller           varchar(5)  not null,
    Datetime         datetime    not null,
    `Customer email` varchar(50) not null,
    primary key (seller, Datetime, `Customer email`),
    constraint `Event subscribes___customers`
        foreign key (`Customer email`) references customers (Email),
    constraint `Event subscribes___events`
        foreign key (seller, Datetime) references events (Seller, Datetime)
);

