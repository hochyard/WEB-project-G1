create table `credit cardes`
(
    `Card number` varchar(30) not null
        primary key,
    First_name    varchar(20) not null,
    Last_name     varchar(20) not null,
    `Date-month`  varchar(5)  not null,
    `Date-year`   varchar(5)  not null,
    CVV           int         not null
);

