create table includes
(
    OrderID   int not null,
    ProductID int not null,
    primary key (OrderID, ProductID),
    constraint Includes_orders_OrderID_fk
        foreign key (OrderID) references orders (OrderID),
    constraint Includes_products_ProductID_fk
        foreign key (ProductID) references products (ProductID)
);

