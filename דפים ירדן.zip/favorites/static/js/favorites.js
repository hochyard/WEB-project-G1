function eraseMesage(){
    alert("הפריט נמחק מהרשימה!")       
}