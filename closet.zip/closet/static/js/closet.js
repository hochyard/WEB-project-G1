function addMesage(){
    alert("הפריט נוסף לרשימת המועדפים")       
}

