create table cities
(
    City_Name varchar(20) not null
        primary key
);

INSERT INTO web_project_g1.cities (City_Name) VALUES ('באר שבע');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('חדרה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('חולון');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('חיפה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('יבנה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('יהוד');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('כפר תבור');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('נתניה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('קיסריה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('רעננה');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('שדרות');
INSERT INTO web_project_g1.cities (City_Name) VALUES ('תל אביב');