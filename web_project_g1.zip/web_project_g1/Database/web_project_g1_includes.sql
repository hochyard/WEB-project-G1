create table includes
(
    OrderID   int not null,
    ProductID int not null,
    primary key (OrderID, ProductID),
    constraint Includes_orders_OrderID_fk
        foreign key (OrderID) references orders (OrderID),
    constraint Includes_products_ProductID_fk
        foreign key (ProductID) references products (ProductID)
);

INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (5, 6);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (2, 7);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (4, 7);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (5, 7);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (4, 18);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (5, 18);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (1, 19);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (3, 21);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (1, 33);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (4, 37);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (1, 39);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (1, 46);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (2, 46);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (4, 46);
INSERT INTO web_project_g1.includes (OrderID, ProductID) VALUES (5, 46);