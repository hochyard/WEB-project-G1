create table credit_cards
(
    Card_number varchar(30) not null
        primary key,
    Full_name   varchar(20) not null,
    Date_month  varchar(10) not null,
    Date_year   varchar(10) not null,
    CVV         varchar(5)  not null
);

INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1212121212121212', 'מיכל לוי', '01', '21', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1234123412341234', 'מיכל לוי', '01', '02', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1234123412341324', 'מיכל לוי', '17', '14', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1234132412341234', 'מיכל לוי', '1', '22', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1235123515815811', 'מיכל לוי', '12', '95', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('1564136415641888', 'מיכל לוי', '13', '25', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('4444444444444444', 'vsav', '01', '52', '123');
INSERT INTO web_project_g1.credit_cards (Card_number, Full_name, Date_month, Date_year, CVV) VALUES ('5864123412341234', 'hutg', '01', '25', '345');