create table customers
(
    Email      varchar(50)      not null
        primary key,
    First_name varchar(30)      not null,
    Last_name  varchar(30)      not null,
    City       varchar(20)      null,
    Password   varchar(20)      not null,
    Commercial char default '0' null,
    constraint Customers___city
        foreign key (City) references cities (City_Name)
);

INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('adidanovich@gmail.com', 'עדי', 'דנוביץ', 'רעננה', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('darpelta@gmail.com', 'דר', 'פלטה', 'יהוד', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('debbyk@gmail.com', 'דבי', 'קלמי', 'חולון', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('galShapira@gmail.com', 'גל', 'שפירא', 'באר שבע', '11111', '0');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('hgreener@gmail.com', 'הדר', 'גרינר', 'חולון', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('liansimon@gmail.com', 'ליאן', 'סימון', 'נתניה', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('mayadvash@gmail.com', 'מאיה', 'דבש', 'באר שבע', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('michallevy@gmail.com', 'מיכל', 'לוי', 'תל אביב', '1212', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('michellevy1@gmail.com', 'מיכל', 'כהן', 'תל אביב', '1234', '0');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('omerbabi@gmail.com', 'עומר', 'באבי', 'חדרה', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('oriklier@gmail.com', 'אורי', 'קלייר', 'תל אביב', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('ronirabinovich@gmail.com', 'רוני ', 'רבינוביץ', 'רעננה', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('sapp@gmail.com', 'ספיר', 'גאלי', 'שדרות', '11111', '1');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('shtal@gmail.com', 'טל', 'שמילוביץ', 'תל אביב', '11111', '0');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('shtal2@gmail.com', 'טל', 'שמילוביץ', 'תל אביב', '11111', '0');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('shtal4@gmail.com', 'טל', 'שמילוביץ', 'תל אביב', '11111', '0');
INSERT INTO web_project_g1.customers (Email, First_name, Last_name, City, Password, Commercial) VALUES ('yardenh@gmail.com', 'ירדן', 'הוכנברג', 'תל אביב', '11111', '1');