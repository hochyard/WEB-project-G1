create table orders
(
    OrderID        int auto_increment
        primary key,
    Full_name      varchar(20) null,
    Adress_street  varchar(20) not null,
    Address_number int         null,
    Customer_email varchar(50) not null,
    Card_number    varchar(30) not null,
    Shipment_price int         not null,
    Address_city   varchar(20) not null,
    constraint `Orders_credit cardes_Card number_fk`
        foreign key (Card_number) references credit_cards (Card_number),
    constraint Orders_customers_Email_fk
        foreign key (Customer_email) references customers (Email)
);

INSERT INTO web_project_g1.orders (OrderID, Full_name, Adress_street, Address_number, Customer_email, Card_number, Shipment_price, Address_city) VALUES (1, 'מיכל לוי', 'שלמה בן יוסף', 13, 'michallevy@gmail.com', '1234123412341234', 0, 'תל אביב - יפו');
INSERT INTO web_project_g1.orders (OrderID, Full_name, Adress_street, Address_number, Customer_email, Card_number, Shipment_price, Address_city) VALUES (2, 'טליה ארלוק', 'הציפור', 55, 'michallevy@gmail.com', '1235123515815811', 20, 'תל אביב');
INSERT INTO web_project_g1.orders (OrderID, Full_name, Adress_street, Address_number, Customer_email, Card_number, Shipment_price, Address_city) VALUES (3, 'מיכל לוי', 'מתת', 1000, 'michallevy@gmail.com', '1212121212121212', 20, 'תל אביב - יפו');
INSERT INTO web_project_g1.orders (OrderID, Full_name, Adress_street, Address_number, Customer_email, Card_number, Shipment_price, Address_city) VALUES (4, 'מיכל לוי', 'ירושמלי', 13, 'michallevy@gmail.com', '1234123412341234', 20, 'תל אביב - יפו');
INSERT INTO web_project_g1.orders (OrderID, Full_name, Adress_street, Address_number, Customer_email, Card_number, Shipment_price, Address_city) VALUES (5, 'bdsaa', 'שלמה המלך', 1, 'michallevy@gmail.com', '1234123412341234', 20, 'bds');