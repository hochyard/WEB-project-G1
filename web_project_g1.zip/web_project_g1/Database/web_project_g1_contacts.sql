create table contacts
(
    ID         int auto_increment
        primary key,
    First_name varchar(20) null,
    Phone      varchar(20) null,
    Last_name  varchar(20) null,
    Email      varchar(50) not null,
    Comment    text        null,
    Seller     varchar(50) null
);

create index Contacts_sellers_Email_fk
    on contacts (Seller);

INSERT INTO web_project_g1.contacts (ID, First_name, Phone, Last_name, Email, Comment, Seller) VALUES (1, 'מיכל', '0544555738', 'לוי', 'michellevy1@gmail.com', 'צרו איתי קשר דחוף', 'עדי דנוביץ');
INSERT INTO web_project_g1.contacts (ID, First_name, Phone, Last_name, Email, Comment, Seller) VALUES (2, 'מיכל', '0544555738', 'לוי', 'michellevy1@gmail.com', 'למה אני לא מקבלת מענה?', 'עדי דנוביץ');