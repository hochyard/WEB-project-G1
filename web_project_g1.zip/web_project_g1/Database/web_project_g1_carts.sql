create table carts
(
    Customer_email varchar(50) not null,
    ProductID      int         not null,
    primary key (Customer_email, ProductID),
    constraint Carts_customers_Email_fk
        foreign key (Customer_email) references customers (Email),
    constraint Carts_products_ProductID_fk
        foreign key (ProductID) references products (ProductID)
);

INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('yardenh@gmail.com', 1);
INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 7);
INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('adidanovich@gmail.com', 19);
INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 21);
INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('hgreener@gmail.com', 27);
INSERT INTO web_project_g1.carts (Customer_email, ProductID) VALUES ('michellevy1@gmail.com', 46);