create table likes
(
    Customer_email varchar(50) not null,
    ProductID      int         not null,
    primary key (Customer_email, ProductID),
    constraint Likes_customers_Email_fk
        foreign key (Customer_email) references customers (Email),
    constraint Likes_products_ProductID_fk
        foreign key (ProductID) references products (ProductID)
);

INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 2);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 6);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 7);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 21);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('mayadvash@gmail.com', 32);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('mayadvash@gmail.com', 35);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 39);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('debbyk@gmail.com', 40);
INSERT INTO web_project_g1.likes (Customer_email, ProductID) VALUES ('michallevy@gmail.com', 46);