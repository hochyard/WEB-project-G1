create table products
(
    ProductID          int auto_increment
        primary key,
    Name               varchar(20) not null,
    Price              double      not null,
    PriceAfterDiscount double      null,
    Brand              varchar(10) null,
    Material           varchar(20) null,
    Seller             varchar(50) null,
    Size               varchar(10) null,
    constraint Products_sellers_Email_fk
        foreign key (Seller) references sellers (Email)
);

INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (1, 'תיק גב נייק', 100, 90, 'NIKE', 'בד', 'yardenh@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (2, 'מגף שחור', 90, 70, 'Steve Madd', 'עור', 'ronirabinovich@gmail.com', '40');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (3, 'מגפון', 100, 60, 'ADDICT', 'עור', 'michallevy@gmail.com', '39');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (4, 'שמלה בגוון אפור', 60, 40, 'HONIGMAN', 'כותנה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (5, 'עגילי חישוק', 10, null, 'ASOS', 'גולדפילד', 'yardenh@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (6, 'נעלי בית', 60, 40, 'ALI', 'פרווה', 'adidanovich@gmail.com', '39');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (7, 'גומייה לשיער', 10, null, 'Super Phar', 'כותנה  ', 'adidanovich@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (8, 'כובע צמר', 20, null, 'Xray', 'צמר 70%', 'yardenh@gmail.com', 'M');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (9, 'נעלי עקב ברונזה', 60, null, 'ALDO', 'עור', 'michallevy@gmail.com', '38');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (10, 'ג''ינס דנים', 120, 110, 'Top Shop', 'ג''ינס', 'ronirabinovich@gmail.com', '36');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (11, 'מכנס טרנינג ', 50, null, 'ASOS', 'כותנה 60%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (12, 'שרשרת', 20, null, 'TOMER & AS', 'ציפוי כסף', 'yardenh@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (13, 'אוברול שחור', 100, 90, 'ZARA', 'כותנה 70%', 'michallevy@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (14, 'מכנס מחויט', 80, null, 'HaCarmel', 'כותנה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (15, 'ארנק שחור', 70, null, 'Gucci', 'עור 80%', 'yardenh@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (16, 'צעיף', 55, 40, 'Prvate Col', 'קשמיר 50%', 'yardenh@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (17, 'חולצת טי-שירט ירח', 40, null, 'FOX', 'כותנה 70%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (18, 'שורט שחור', 40, null, 'Top Shop', 'כותנה 80%', 'adidanovich@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (19, 'חצאית קורדרוי', 60, 30, 'Mando', 'קורדרוי', 'adidanovich@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (20, 'חצאית וינטג''', 50, null, 'GRIP', 'כותנה 50%', 'yardenh@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (21, 'טרנינג נייק', 130, null, 'Nike', 'כותנה 80%', 'adidanovich@gmail.com', 'M');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (22, 'שורט נקודות', 40, null, 'ASOS', 'כותנה 50%', 'yardenh@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (23, 'טופ ספורט נייק', 70, null, 'NIKE', 'לייקרה 70%', 'ronirabinovich@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (24, 'טישרט בייסיק לבנה', 30, null, 'FOX', 'לייקרה 70%', 'yardenh@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (25, 'תיק גב נייק', 100, 90, 'NIKE', 'בד', 'hgreener@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (26, 'מגף שחור', 90, 70, 'Steve Madd', 'עור', 'hgreener@gmail.com', '40');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (27, 'מגפון', 100, 60, 'ADDICT', 'עור', 'hgreener@gmail.com', '39');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (28, 'שמלה בגוון אפור', 60, 40, 'HONIGMAN', 'כותנה 70%', 'hgreener@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (29, 'עגילי חישוק', 10, null, 'ASOS', 'גולדפילד', 'hgreener@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (30, 'נעלי בית', 60, 40, 'ALI', 'פרווה', 'mayadvash@gmail.com', '39');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (31, 'גומייה לשיער', 10, null, 'Super Phar', 'פוליאסטר', 'mayadvash@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (32, 'כובע צמר', 20, null, 'Xray', 'צמר 70%', 'mayadvash@gmail.com', 'M');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (33, 'נעלי עקב ברונזה', 60, null, 'ALDO', 'זמש', 'mayadvash@gmail.com', '38');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (34, 'ג''ינס ארוך בהיר', 120, 110, 'Top Shop', 'ג''ינס', 'mayadvash@gmail.com', '36');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (35, 'מכנס טרנינג ', 50, null, 'ASOS', 'כותנה 60%', 'mayadvash@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (36, 'שרשרת', 20, null, 'TOMER & AS', 'ציפוי כסף', 'liansimon@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (37, 'אוברול שחור', 100, 90, 'ZARA', 'כותנה 70%', 'liansimon@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (38, 'מכנס מחויט', 80, null, 'HaCarmel', 'כותנה 70%', 'liansimon@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (39, 'ארנק שחור', 70, null, 'Gucci', 'עור 80%', 'debbyk@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (40, 'צעיף', 55, 40, 'Prvate Col', 'קשמיר 50%', 'debbyk@gmail.com', 'OS');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (41, 'חולצת טי-שירט ירח', 40, null, 'FOX', 'כותנה 70%', 'sapp@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (42, 'שורט שחור', 40, null, 'Top Shop', 'כותנה 80%', 'omerbabi@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (43, 'חצאית קורדרוי', 60, 30, 'Mando', 'קורדרוי', 'omerbabi@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (44, 'חצאית וינטג''', 50, null, 'GRIP', 'כותנה 50%', 'omerbabi@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (45, 'טרנינג נייק', 130, null, 'Nike', 'כותנה 80%', 'omerbabi@gmail.com', 'M');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (46, 'שורט נקודות', 40, null, 'ASOS', 'כותנה 50%', 'darpelta@gmail.com', 'S');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (47, 'טופ ספורט נייק', 70, null, 'NIKE', 'לייקרה 70%', 'oriklier@gmail.com', 'L');
INSERT INTO web_project_g1.products (ProductID, Name, Price, PriceAfterDiscount, Brand, Material, Seller, Size) VALUES (48, 'טישרט בייסיק לבנה', 30, null, 'FOX', 'לייקרה 70%', 'oriklier@gmail.com', 'S');