from utilities.db.db_manager import dbManager

class DB_register:
    def __init_(self):
        pass

    def check_if_email_exists(self,customer_email):
        email_exists = dbManager.fetch('SELECT * FROM customers WHERE Email=%s ', (customer_email,))
        return email_exists

    def insert_new_customer(self,email, first_name, last_name, city, password, comer):
        dbManager.commit('INSERT INTO customers VALUES(%s,%s,%s,%s,%s,%s)',
                                        (email, first_name, last_name, city, password, comer))

    def check_password(self,customer_email, password):
        email_exists = dbManager.fetch('SELECT * FROM customers WHERE email=%s AND password=%s', (customer_email, password))
        return email_exists

    def update_password(self,new_password, email):
        dbManager.commit('''UPDATE customers SET password=%s WHERE Email=%s''', (new_password, email))


db_register = DB_register()