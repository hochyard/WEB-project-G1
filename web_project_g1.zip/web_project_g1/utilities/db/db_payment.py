from utilities.db.db_manager import dbManager
from utilities.db.db_cart import db_cart


class DB_payment:
    def __init_(self):
        pass

    def get_products_in_cart(self,user_email):
        products_in_cart = dbManager.fetch('''SELECT c.Customer_email,s.Email,cu.First_name,cu.Last_name,cast((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as CHAR(10)) as Price_as_char,(case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as Price, p.ProductID,p.Name,pp.Photo_URL
                                                FROM carts as c join products as p on c.ProductID=p.ProductID join sellers as s on s.Email=p.Seller join customers as cu on cu.Email=s.Email join product_photos as pp on pp.ProductID=p.ProductID
                                                WHERE c.Customer_email=%s
                                                ORDER BY s.Email,p.ProductID''', (user_email,))
        return products_in_cart

    def calculate_total_order(self,user_email):
        return db_cart.calculate_total_order_price(user_email)

    def get_credit_card(self,card_number):
        card = dbManager.fetch('''SELECT *
                                        FROM credit_cards as c
                                        WHERE c.Card_number=%s
                                        ''', (card_number,))
        return card

    def insert_new_credit_card(self,cardnumber, full_name_card, expmonth, expyear, cvv):
        dbManager.commit('''INSERT INTO credit_cards
                                             VALUES(%s,%s,%s,%s,%s)''',(cardnumber, full_name_card, expmonth, expyear, cvv))

    def insert_new_order(self,full_name_delivery, address_street, address_number, email, cardnumber, shipment_price,city):
        id = len(dbManager.fetch('''SELECT * FROM orders''')) + 1
        dbManager.commit('''INSERT INTO orders VALUES(%s,%s,%s,%s,%s,%s,%s,%s)''',
                         (id, full_name_delivery, address_street, address_number, email, cardnumber, shipment_price,city))
    def get_user_products_cart(self,user_email):
        return db_cart.get_user_products_in_cart(user_email)

    def insert_products_to_order(self,product_id):
        id = len(dbManager.fetch('''SELECT * FROM orders'''))
        dbManager.commit('''INSERT INTO includes VALUES(%s,%s)''', (id, product_id))

    def delete_products_from_cart(self,user_email):
        dbManager.commit('''delete from carts as c where c.Customer_email=%s''',(user_email,))

db_payment = DB_payment()