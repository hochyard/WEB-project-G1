from utilities.db.db_manager import dbManager

class DB_contact_us:
    def __init_(self):
        pass

    def get_sellers_names(self):
        sellers = dbManager.fetch('''SELECT c.First_name,c.Last_name
                                        FROM sellers as s join customers as c on c.Email=s.Email''')
        return sellers

    def create_new_customer_contact(self,firstname,phone, lastname, email, comments, seller):
        id = len(dbManager.fetch('''SELECT * FROM contacts''')) + 1
        dbManager.commit('''INSERT INTO contacts
                                         VALUES(%s,%s,%s,%s,%s,%s,%s)''',
                         (id, firstname, phone, lastname, email, comments, seller))


db_contact_us = DB_contact_us()