from utilities.db.db_manager import dbManager

class DB_cart:
    def __init_(self):
        pass

    def get_user_products_in_cart(self,user_email):
        products_in_cart = dbManager.fetch('''SELECT c.Customer_email,s.Email,cu.First_name,cu.Last_name,cast((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as CHAR(10)) as Price_as_char,(case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as Price, p.ProductID,p.Name,pp.Photo_URL
                                                FROM carts as c join products as p on c.ProductID=p.ProductID join sellers as s on s.Email=p.Seller join customers as cu on cu.Email=s.Email join product_photos as pp on pp.ProductID=p.ProductID
                                                WHERE c.Customer_email=%s
                                                ORDER BY s.Email,p.ProductID''', (user_email,))
        return products_in_cart

    def calculate_total_order_price(self,user_email):
        total_order = dbManager.fetch('''SELECT sum((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end)) as Total_Price
                                                    FROM carts as c join products as p on c.ProductID=p.ProductID
                                                    WHERE c.Customer_email=%s
                                                    ''', (user_email,))
        return total_order

    def delete_product_from_cart(self,user_email,product_id):
        dbManager.commit('''delete from carts as c where c.Customer_email=%s and c.ProductID = %s''',
                         (user_email, product_id))


db_cart = DB_cart()