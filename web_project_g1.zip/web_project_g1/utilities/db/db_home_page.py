from utilities.db.db_manager import dbManager

class DB_home_page:
    def __init_(self):
        pass

    def get_sellers(self):
        sellers = dbManager.fetch(''' SELECT c.email, c.First_name,c.Last_name,s.Photo_URL FROM sellers as s join customers as c on c.email=s.email''')
        return sellers


db_home_page = DB_home_page()