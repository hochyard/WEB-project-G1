from utilities.db.db_manager import dbManager

class DB_sale:
    def __init_(self):
        pass

    def get_products(self,price_h,price_l):
        sale_products = dbManager.fetch('''
                                       SELECT p.ProductID,p.Name,pp.Photo_URL,cast(p.PriceAfterDiscount as CHAR(10)) as Price_after,cast(p.Price as CHAR(10)) as Price_before
                                       FROM products as p join product_photos as pp on pp.ProductID=p.ProductID
                                       WHERE p.PriceAfterDiscount is not null and p.PriceAfterDiscount>=%s and p.PriceAfterDiscount<=%s
                                       ORDER BY p.ProductID''',(price_h,price_l))
        print(sale_products)
        return sale_products

db_sale = DB_sale()