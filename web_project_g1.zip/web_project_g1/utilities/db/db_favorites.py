from utilities.db.db_manager import dbManager

class DB_favorites:
    def __init_(self):
        pass

    def get_products_in_favorites(self,user_email):
        products_in_fav = dbManager.fetch('''SELECT p.ProductID,cast((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as CHAR(10)) as Price,p.Name,pp.Photo_URL
                                                  FROM likes as l join Products as p on p.ProductID=l.ProductID join product_photos as pp on pp.ProductID=p.ProductID 
                                                  WHERE l.Customer_email=%s 
                                                  ORDER BY p.ProductID''', (user_email,))
        return products_in_fav

    def delete_products_from_favorites(self,user_email, product_id):
        dbManager.commit('''DELETE from likes as l where l.Customer_email=%s and l.ProductID = %s''',(user_email, product_id))

db_favorites = DB_favorites()