from utilities.db.db_manager import dbManager

class DB_products:
    def __init_(self):
        pass

    def get_product_details(self,product_id):
        product_details = dbManager.fetch('''
                  SELECT p.ProductID,cast((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as CHAR(10)) as Price,pp.Photo_URL,p.Name,p.Brand,p.Material,p.Seller,p.Size,c.First_name,c.Last_name
                  FROM product_photos as pp join products as p on p.ProductID=pp.ProductID join sellers as s on s.Email=p.Seller join customers as c on c.Email=s.Email
                  WHERE pp.ProductID = %s
                  ''', (product_id,))
        return product_details

    def check_if_product_exist_in_cart(self,product_to_add, customer_email):
        products_in_cart = dbManager.fetch('''
                                               SELECT *
                                               FROM carts as c 
                                               WHERE c.ProductID=%s and c.Customer_email=%s
                                               ''', (product_to_add, customer_email))
        return products_in_cart
    def insert_new_product_to_cart(self,customer_email, product_to_add):
        dbManager.commit('''INSERT INTO carts VALUES(%s,%s)''',(customer_email, product_to_add))

db_products = DB_products()