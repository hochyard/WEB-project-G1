from utilities.db.db_manager import dbManager

class DB_events:
    def __init_(self):
        pass

    def get_events(self):
        events = dbManager.fetch('''   SELECT c.First_name,c.Last_name,s.Photo_URL,date(e.Datetime) as date,time(e.Datetime) as time,e.Address_city as city
                                           FROM events as e join sellers as s on s.Email=e.Seller join customers as c on c.Email=s.Email
                                           WHERE e.Datetime>=CURDATE()
                                           ''')
        return events

db_events = DB_events()