from utilities.db.db_manager import dbManager

class DB_closet:
    def __init_(self):
        pass

    def get_seller_closet(self,seller_email):
        seller_products = dbManager.fetch('''
                                   SELECT s.email,c.First_name,c.Last_name,s.Photo_URL,s.Description,p.ProductID, pp.photo_URL as p_URL, p.Name, cast((case when p.PriceAfterDiscount is null then p.Price else p.PriceAfterDiscount end) as CHAR(10)) as Price
                                   FROM product_photos as pp join products as p on p.ProductID=pp.ProductID join sellers as s on s.email=p.seller join customers as c on c.email=s.email
                                   WHERE s.email = %s  
                                   ORDER BY p.productID
                                   ''', (seller_email,))
        return seller_products

    def get_favorite_products_in_seller_closet(self,seller_email,customer_email):
        customers_likes = dbManager.fetch('''
                                       SELECT l.ProductID
                                       FROM likes as l join products as p on l.ProductID=p.ProductID
                                       WHERE p.Seller=%s and l.Customer_email=%s
                                   ''', (seller_email, customer_email))
        return customers_likes

    def get_user_favorite_products(self,user_email,product_id):
        product_exist_in_fav = dbManager.fetch('''
                                       SELECT *
                                       FROM likes as l 
                                       WHERE l.ProductID=%s and l.Customer_email=%s
                                       ''', (product_id, user_email))
        return product_exist_in_fav

    def add_new_product_to_favorite(self,user_email, product_id):
        dbManager.commit('''INSERT INTO likes
                                 VALUES(%s,%s)''',(user_email, product_id))


db_closet = DB_closet()