from flask import Flask



###### App setup
app = Flask(__name__)
app.config.from_pyfile('settings.py')

###### Pages
## Homepage
from pages.home_page.home_page import home_page
app.register_blueprint(home_page)

from pages.closet.closet import closet
app.register_blueprint(closet)

from pages.product.product import product
app.register_blueprint(product)

from pages.register.register import register
app.register_blueprint(register)

from pages.favorites.favorites import favorites
app.register_blueprint(favorites)

from pages.terms_of_use.terms_of_use import terms_of_use
app.register_blueprint(terms_of_use)

from pages.cart.cart import cart
app.register_blueprint(cart)

from pages.payment.payment import payment
app.register_blueprint(payment)

from pages.sale.sale import sale
app.register_blueprint(sale)

from pages.events.events import events
app.register_blueprint(events)

from pages.qa.qa import qa
app.register_blueprint(qa)

from pages.who_we_are.who_we_are import who_we_are
app.register_blueprint(who_we_are)

from pages.Exchange_Returns.Exchange_Returns import Exchange_Returns
app.register_blueprint(Exchange_Returns)

from pages.contact_us.contact_us import contact_us
app.register_blueprint(contact_us)


## header
from components.header.header import header
app.register_blueprint(header)

from components.footer.footer import footer
app.register_blueprint(footer)



