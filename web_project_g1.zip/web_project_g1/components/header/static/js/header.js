function openLoginForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeLoginForm() {
document.getElementById("myForm").style.display = "none";
}