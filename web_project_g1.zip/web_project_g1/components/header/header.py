from flask import Blueprint, render_template, request, flash,session,redirect,url_for
from utilities.db.db_register import db_register

# header blueprint definition
header= Blueprint('header', __name__, static_folder='static', static_url_path='/header', template_folder='templates')

@header.route('/log_in', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if session:
            email = request.values.get('email')
            password = request.values.get('psw')
            new_password = request.values.get('psw_new')
            email_exists = db_register.check_password(email, password)
            if email_exists:
                db_register.update_password(new_password,email)
                flash("הסיסמה שונתה בהצלחה")
                return redirect(url_for("home_page.index"))
            else:
                flash("הסיסמה או האימייל אינם נכונים")
                return redirect(url_for("home_page.index"))
        else:
            email = request.values.get('email')
            password = request.values.get('psw')
            email_exists = db_register.check_password(email, password)
            if email_exists:
                session['logged_in'] = True
                session['user'] = {
                    'email': email_exists[0].Email,
                    'first_name': email_exists[0].First_name,
                    'last_name': email_exists[0].Last_name,
                    'password': email_exists[0].Password
                }
                return redirect(url_for("home_page.index"))
            else:
                flash("הסיסמה או האימייל אינם נכונים")
                return redirect(url_for("home_page.index"))

