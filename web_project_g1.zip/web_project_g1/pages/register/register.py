from flask import Blueprint, render_template, request, flash,session,redirect,url_for
from utilities.db.db_register import db_register

# register blueprint definition
register = Blueprint('register',
                     __name__,
                     static_folder='static',
                     static_url_path='/register',
                     template_folder='templates')


# Routes
@register.route('/register', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        email = request.form['e-mail']
        first_name = request.form['firstname']
        last_name = request.form['lastname']
        city = request.form['city']
        password = request.form['password']
        comer = request.values.get('com')
        if comer == 'on':
            comer = 1
        else:
            comer = 0
        email_exists = db_register.check_if_email_exists(email)
        if email_exists:
            flash("האימייל כבר קיים במערכת")
            return render_template('register.html')
        else:
            db_register.insert_new_customer(email, first_name, last_name, city, password, comer)
            flash("!נרשמת בהצלחה")
            session['logged_in'] = True
            session['user'] = {
                'email': email,
                'first_name': first_name,
                'last_name': last_name,
                'password': password
                }
            return redirect(url_for("home_page.index"))

    return render_template('register.html')


@register.route('/log_out')
def logout():
    session.clear()
    return redirect(url_for("home_page.index"))
