from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_manager import dbManager

# qa blueprint definition
qa = Blueprint('qa',
                  __name__,
                  static_folder='static',
                  static_url_path='/qa',
                  template_folder='templates')

# Routes
@qa.route('/qa')
def index():
    return render_template('qa.html')