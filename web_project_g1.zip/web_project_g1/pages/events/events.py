from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_events import db_events

# events blueprint definition
events = Blueprint('events',
                  __name__,
                  static_folder='static',
                  static_url_path='/events',
                  template_folder='templates')

# Routes
@events.route('/events')
def index():
    events = db_events.get_events()
    return render_template('events.html', events=events)