from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_cart import db_cart

# cart blueprint definition
cart = Blueprint('cart',
                  __name__,
                  static_folder='static',
                  static_url_path='/cart',
                  template_folder='templates')

# Routes
@cart.route('/cart')
def index():
    email = session['user']['email']
    products_in_cart = db_cart.get_user_products_in_cart(email)
    total_order = db_cart.calculate_total_order_price(email)
    return render_template('cart.html', products_in_cart=products_in_cart,total_order=total_order)

@cart.route('/erase_from_cart')
def erase_product_from_cart():
    email = session['user']['email']
    product_id = request.args['id']
    db_cart.delete_product_from_cart(email,product_id)
    return redirect(url_for("cart.index"))

