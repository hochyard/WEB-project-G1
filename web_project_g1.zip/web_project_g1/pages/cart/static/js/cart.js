function addMesage(){
    alert("הפריט נמחק בהצלחה")       
}

