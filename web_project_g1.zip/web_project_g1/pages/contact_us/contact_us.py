from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_contact_us import db_contact_us

# contact_us blueprint definition
contact_us = Blueprint('contact_us',
                  __name__,
                  static_folder='static',
                  static_url_path='/contact_us',
                  template_folder='templates')

# Routes
@contact_us.route('/contact_us')
def index():
    sellers = db_contact_us.get_sellers_names()
    return render_template('contact_us.html',sellers=sellers)

@contact_us.route('/contact_us_submit',methods=['GET', 'POST'])
def contact_us_submit():
    if request.method == 'GET':
        firstname = request.args['firstname']
        lastname = request.args['lastname']
        seller = request.args['seller']
        phone = request.args['phone']
        email = request.args['email']
        comments = request.args['comments']
        flash('תודה! הבקשה נשלחה')
        db_contact_us.create_new_customer_contact(firstname, phone,lastname,email,comments,seller)
    return redirect(url_for("home_page.index"))

