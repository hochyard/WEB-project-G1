from flask import Blueprint, render_template, request
from utilities.db.db_manager import dbManager

# terms_of_use blueprint definition
terms_of_use = Blueprint('terms_of_use',
                  __name__,
                  static_folder='static',
                  static_url_path='/terms_of_use',
                  template_folder='templates')

# Routes
@terms_of_use.route('/terms_of_use')
def index():
    return render_template('terms_of_use.html')