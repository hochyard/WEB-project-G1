from flask import Blueprint, render_template, request, flash,session,redirect,url_for
from utilities.db.db_favorites import db_favorites

# register blueprint definition
favorites = Blueprint('favorites',
                     __name__,
                     static_folder='static',
                     static_url_path='/favorites',
                     template_folder='templates')

@favorites.route('/favorites')
def index():
    email = session['user']['email']
    products_in_fav = db_favorites.get_products_in_favorites(email)
    return render_template('favorites.html', products_in_fav=products_in_fav)

@favorites.route('/erase_from_fav')
def erase_product():
    email = session['user']['email']
    product_id = request.args['id']
    db_favorites.delete_products_from_favorites(email,product_id)
    return redirect(url_for("favorites.index"))

