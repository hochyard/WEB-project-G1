from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_closet import db_closet

# closet blueprint definition
closet = Blueprint('closet',
                  __name__,
                  static_folder='static',
                  static_url_path='/closet',
                  template_folder='templates')

# Routes
@closet.route('/closet')
def index():
    if 'email' in request.args:
        seller_email = request.args['email']
        seller_products = db_closet.get_seller_closet(seller_email)
        if session:
            customer_email=session['user']['email']
            customers_likes = db_closet.get_favorite_products_in_seller_closet(seller_email,customer_email)
            return render_template('closet.html', products=seller_products,customers_likes=customers_likes)
        if seller_products:
            return render_template('closet.html', products = seller_products)
    return render_template('closet.html')

@closet.route('/insert_to_fav')
def insert_to_favorites():
    email = session['user']['email']
    seller_email=request.args['seller']
    product_id = request.args['id']
    product_exist_in_fav = db_closet.get_user_favorite_products(product_id,email)
    if product_exist_in_fav==[]:
        db_closet.add_new_product_to_favorite(email,product_id)
    seller_products = db_closet.get_seller_closet(seller_email)
    customers_likes = db_closet.get_favorite_products_in_seller_closet(seller_email,email)
    if seller_products:
        return render_template('closet.html', products=seller_products,customers_likes=customers_likes)
    return redirect(url_for("closet.index"))

