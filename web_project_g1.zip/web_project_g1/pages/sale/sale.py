from flask import Blueprint, render_template, request, flash,session,redirect,url_for
from utilities.db.db_sale import db_sale

# register blueprint definition
sale = Blueprint('sale',
                     __name__,
                     static_folder='static',
                     static_url_path='/sale',
                     template_folder='templates')


# Routes
@sale.route('/filter_all', methods=['GET', 'POST'])
@sale.route('/sale', methods=['GET', 'POST'])
def index():
    sale_products = db_sale.get_products(0,1000)
    return render_template('sale.html', sale_products=sale_products)


@sale.route('/filter_less40', methods=['GET', 'POST'])
def index2():
    sale_products = db_sale.get_products(0,39)
    return render_template('sale.html', sale_products=sale_products)


@sale.route('/filter_less40100', methods=['GET', 'POST'])
def index3():
    sale_products = db_sale.get_products(40,100)
    return render_template('sale.html', sale_products=sale_products)

@sale.route('/filter_biggerThen100', methods=['GET', 'POST'])
def index4():
    sale_products = db_sale.get_products(101,1000)
    return render_template('sale.html', sale_products=sale_products)

