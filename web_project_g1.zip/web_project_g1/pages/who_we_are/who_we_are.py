from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_manager import dbManager

# who_we_are blueprint definition
who_we_are = Blueprint('who_we_are',
                  __name__,
                  static_folder='static',
                  static_url_path='/who_we_are',
                  template_folder='templates')

# Routes
@who_we_are.route('/who_we_are')
def index():
    return render_template('who_we_are.html')
