from flask import Blueprint, render_template, request,session,redirect,url_for,flash
from utilities.db.db_payment import db_payment

# closet blueprint definition
payment = Blueprint('payment',
                  __name__,
                  static_folder='static',
                  static_url_path='/payment',
                  template_folder='templates')

# Routes
@payment.route('/payment')
def index():
    email = session['user']['email']
    products_in_cart = db_payment.get_products_in_cart(email)
    total_order = db_payment.calculate_total_order(email)
    return render_template('payment.html', products_in_cart=products_in_cart, total_order=total_order)


@payment.route('/add_order', methods=['GET', 'POST'])
def add_new_order():
    if request.method == 'POST':
        email = session['user']['email']
        full_name_delivery = request.form['full-name']
        address_street=request.form['adrS']
        address_number=request.form['adrN']
        city=request.form['city']
        full_name_card = request.form['cname']
        cardnumber = request.form['ccnum']
        expmonth=request.form['expmonth']
        expyear=request.form['expyear']
        cvv=request.form['cvv']
        total_order = db_payment.calculate_total_order(email)
        if total_order[0].Total_Price >= 199:
            shipment_price = 0
        else:
            shipment_price = 20
        card = db_payment.get_credit_card(cardnumber)

        if card == []:
            db_payment.insert_new_credit_card(cardnumber, full_name_card, expmonth, expyear, cvv)

        db_payment.insert_new_order(full_name_delivery, address_street, address_number, email, cardnumber,shipment_price,city)
        products_in_cart = db_payment.get_user_products_cart(email)
        for product in products_in_cart:
            p = product.ProductID
            db_payment.insert_products_to_order(p)

        db_payment.delete_products_from_cart(email)
        flash('!ההזמנה בוצעה בהצלחה')
        return redirect(url_for('home_page.index'))
    else:
        return redirect(url_for('payment.index'))


