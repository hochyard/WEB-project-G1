from flask import Blueprint, render_template, request
from utilities.db.db_home_page import db_home_page


# home_page blueprint definition
home_page = Blueprint('home_page',
                  __name__,
                  static_folder='static',
                  static_url_path='/home_page',
                  template_folder='templates')

# Routes
@home_page.route('/')
@home_page.route('/home_page')
def index():
    sellers = db_home_page.get_sellers()
    return render_template('home_page.html',sellers = sellers)