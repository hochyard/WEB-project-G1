from flask import Blueprint, render_template, request,session,flash,redirect,url_for
from utilities.db.db_products import db_products

# product blueprint definition
product = Blueprint('product',
                  __name__,
                  static_folder='static',
                  static_url_path='/product',
                  template_folder='templates')

# Routes
@product.route('/product')
def index():
    if 'id' in request.args:
        product_id = request.args['id']
        product_details = db_products.get_product_details(product_id)
        if product_details:
            return render_template('product.html', items=product_details)
    return render_template('product.html')


@product.route('/add_to_cart')
def add_item_to_cart():
    product_to_add = request.args['id']
    if session:
        customer_email = session['user']['email']
        products_in_cart = db_products.check_if_product_exist_in_cart(product_to_add, customer_email)
        if products_in_cart:
            flash('!הפריט כבר נמצא בסל')
        else:
            flash('הפריט נוסף בהצלחה')
            db_products.insert_new_product_to_cart(customer_email, product_to_add)
    else:
        flash('ניתן להוסיף פריט לסל רק לאחר ההרשמה לאתר')
    product_details = db_products.get_product_details(product_to_add)
    return render_template('product.html', items=product_details)


